import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image, FlatList } from 'react-native';
import { useTheme } from 'react-native-paper';
import i18n from '../localization/i18n';

// Placeholder for images - in a real app, these would be actual image assets
const PLACEHOLDER_IMAGE = 'https://via.placeholder.com/150';

// Sample favorites data
const SAMPLE_FAVORITES = [
  { 
    id: '1', 
    title: 'بطاقة عيد ميلاد', 
    category: 'birthday', 
    image: PLACEHOLDER_IMAGE,
    date: '2025-05-15',
    type: 'greeting'
  },
  { 
    id: '2', 
    title: 'ستوري رمضان', 
    category: 'ramadan', 
    image: PLACEHOLDER_IMAGE,
    date: '2025-05-10',
    type: 'story'
  },
  { 
    id: '3', 
    title: 'بطاقة زفاف كلاسيكية', 
    category: 'wedding', 
    image: PLACEHOLDER_IMAGE,
    date: '2025-05-05',
    type: 'wedding'
  },
];

const FavoritesScreen = ({ navigation }: any) => {
  const theme = useTheme();
  const [favorites, setFavorites] = useState(SAMPLE_FAVORITES);
  const [activeFolder, setActiveFolder] = useState('all');

  const folders = [
    { id: 'all', name: 'الكل' },
    { id: 'greeting', name: 'بطاقات التهنئة' },
    { id: 'story', name: 'تصاميم ستوري' },
    { id: 'wedding', name: 'بطاقات أفراح' },
  ];

  const filteredFavorites = activeFolder === 'all' 
    ? favorites 
    : favorites.filter(item => item.type === activeFolder);

  const handleEditFavorite = (item) => {
    // Navigate to the appropriate editor based on the item type
    switch (item.type) {
      case 'greeting':
        navigation.navigate('CardEditor', { card: item });
        break;
      case 'story':
        navigation.navigate('StoryEditor', { design: item });
        break;
      case 'wedding':
        navigation.navigate('WeddingCardEditor', { card: item });
        break;
      default:
        break;
    }
  };

  const handleRemoveFavorite = (id) => {
    setFavorites(prevFavorites => prevFavorites.filter(item => item.id !== id));
  };

  const renderFavoriteItem = ({ item }) => (
    <View style={styles.favoriteItem}>
      <View style={styles.favoriteThumbnail}>
        <Image source={{ uri: item.image }} style={styles.thumbnailImage} />
      </View>
      <View style={styles.favoriteDetails}>
        <Text style={styles.favoriteTitle}>{item.title}</Text>
        <Text style={styles.favoriteCategory}>
          {folders.find(folder => folder.id === item.type)?.name || item.type}
        </Text>
        <Text style={styles.favoriteDate}>
          {new Date(item.date).toLocaleDateString('ar-SA')}
        </Text>
        <View style={styles.favoriteActions}>
          <TouchableOpacity 
            style={styles.editButton}
            onPress={() => handleEditFavorite(item)}
          >
            <Text style={styles.actionButtonText}>تعديل</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.removeButton}
            onPress={() => handleRemoveFavorite(item.id)}
          >
            <Text style={styles.actionButtonText}>إزالة</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{i18n.t('favorites')}</Text>
      </View>

      <View style={styles.foldersContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.foldersScrollContent}
        >
          {folders.map(folder => (
            <TouchableOpacity
              key={folder.id}
              style={[
                styles.folderTab,
                activeFolder === folder.id && styles.activeFolder
              ]}
              onPress={() => setActiveFolder(folder.id)}
            >
              <Text style={[
                styles.folderText,
                activeFolder === folder.id && styles.activeFolderText
              ]}>
                {folder.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {filteredFavorites.length > 0 ? (
        <FlatList
          data={filteredFavorites}
          renderItem={renderFavoriteItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.favoritesContainer}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>{i18n.t('noFavorites')}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8FA',
  },
  header: {
    padding: 15,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#D4AF37',
  },
  foldersContainer: {
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  foldersScrollContent: {
    paddingHorizontal: 15,
  },
  folderTab: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginRight: 10,
  },
  activeFolder: {
    backgroundColor: '#FFD1DC',
  },
  folderText: {
    fontSize: 14,
    color: '#666',
  },
  activeFolderText: {
    color: '#333',
    fontWeight: 'bold',
  },
  favoritesContainer: {
    padding: 15,
  },
  favoriteItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 10,
    overflow: 'hidden',
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  favoriteThumbnail: {
    width: 100,
    height: 150,
  },
  thumbnailImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  favoriteDetails: {
    flex: 1,
    padding: 15,
  },
  favoriteTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  favoriteCategory: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  favoriteDate: {
    fontSize: 12,
    color: '#888',
    marginBottom: 10,
  },
  favoriteActions: {
    flexDirection: 'row',
  },
  editButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 15,
    backgroundColor: '#BFEAF5',
    marginRight: 10,
  },
  removeButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 15,
    backgroundColor: '#FFD1DC',
  },
  actionButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#333',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: '#888',
    textAlign: 'center',
  },
});

export default FavoritesScreen;
