import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image, FlatList } from 'react-native';
import { useTheme } from 'react-native-paper';
import i18n from '../localization/i18n';

// Placeholder for images - in a real app, these would be actual image assets
const PLACEHOLDER_IMAGE = 'https://via.placeholder.com/150';

// Categories for story designs
const CATEGORIES = [
  { id: '1', name: i18n.t('instagram') },
  { id: '2', name: i18n.t('whatsapp') },
  { id: '3', name: i18n.t('snapchat') },
];

// Sample story designs data
const STORY_DESIGNS = [
  { id: '1', title: 'ستوري رمضان', category: '1', image: PLACEHOLDER_IMAGE },
  { id: '2', title: 'ستوري عيد', category: '1', image: PLACEHOLDER_IMAGE },
  { id: '3', title: 'ستوري تهنئة', category: '2', image: PLACEHOLDER_IMAGE },
  { id: '4', title: 'ستوري مناسبات', category: '2', image: PLACEHOLDER_IMAGE },
  { id: '5', title: 'ستوري أفراح', category: '3', image: PLACEHOLDER_IMAGE },
  { id: '6', title: 'ستوري مواليد', category: '3', image: PLACEHOLDER_IMAGE },
];

const StoryDesignsScreen = ({ navigation }: any) => {
  const theme = useTheme();
  const [selectedCategory, setSelectedCategory] = React.useState('all');

  const filteredDesigns = selectedCategory === 'all' 
    ? STORY_DESIGNS 
    : STORY_DESIGNS.filter(design => design.category === selectedCategory);

  const renderDesignItem = ({ item }: { item: { id: string, title: string, category: string, image: string } }) => (
    <TouchableOpacity
      style={styles.designItem}
      onPress={() => navigation.navigate('StoryEditor', { design: item })}
    >
      <Image source={{ uri: item.image }} style={styles.designImage} />
      <View style={styles.designContent}>
        <Text style={styles.designTitle}>{item.title}</Text>
        <Text style={styles.designCategory}>
          {CATEGORIES.find(cat => cat.id === item.category)?.name || ''}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{i18n.t('storyDesigns')}</Text>
      </View>

      <View style={styles.categoriesContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesScrollContent}
        >
          <TouchableOpacity
            style={[
              styles.categoryItem,
              selectedCategory === 'all' && { backgroundColor: '#FFD1DC' }
            ]}
            onPress={() => setSelectedCategory('all')}
          >
            <Text style={[
              styles.categoryText,
              selectedCategory === 'all' && { color: '#333' }
            ]}>
              الكل
            </Text>
          </TouchableOpacity>
          
          {CATEGORIES.map(category => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryItem,
                selectedCategory === category.id && { backgroundColor: '#FFD1DC' }
              ]}
              onPress={() => setSelectedCategory(category.id)}
            >
              <Text style={[
                styles.categoryText,
                selectedCategory === category.id && { color: '#333' }
              ]}>
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filteredDesigns}
        renderItem={renderDesignItem}
        keyExtractor={item => item.id}
        horizontal={false}
        contentContainerStyle={styles.designsContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8FA', // Light pink background
  },
  header: {
    padding: 15,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#D4AF37', // Gold color
  },
  categoriesContainer: {
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  categoriesScrollContent: {
    paddingHorizontal: 15,
  },
  categoryItem: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginRight: 10,
  },
  categoryText: {
    fontSize: 14,
    color: '#666',
  },
  designsContainer: {
    padding: 10,
  },
  designItem: {
    marginBottom: 15,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  designImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  designContent: {
    padding: 12,
  },
  designTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  designCategory: {
    fontSize: 14,
    color: '#888',
  },
});

export default StoryDesignsScreen;
