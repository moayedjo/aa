import React, { useState } from 'react';
import './ShareFeature.css';

// مكون خاصية المشاركة
const ShareFeature = ({ designTitle = 'تصميم جديد' }) => {
  const [showShareOptions, setShowShareOptions] = useState(false);
  const [scheduleMode, setScheduleMode] = useState(false);
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleTime, setScheduleTime] = useState('');
  const [recipient, setRecipient] = useState('');

  // فتح خيارات المشاركة
  const toggleShareOptions = () => {
    setShowShareOptions(!showShareOptions);
    setScheduleMode(false);
  };

  // تبديل وضع الجدولة
  const toggleScheduleMode = () => {
    setScheduleMode(!scheduleMode);
  };

  // مشاركة عبر واتساب
  const shareViaWhatsApp = () => {
    alert('جاري فتح واتساب للمشاركة...');
    // في التطبيق الحقيقي، سيتم استخدام رابط مشاركة واتساب
  };

  // مشاركة عبر إنستغرام
  const shareViaInstagram = () => {
    alert('جاري فتح إنستغرام للمشاركة...');
    // في التطبيق الحقيقي، سيتم استخدام رابط مشاركة إنستغرام
  };

  // مشاركة عبر البريد الإلكتروني
  const shareViaEmail = () => {
    alert('جاري فتح البريد الإلكتروني للمشاركة...');
    // في التطبيق الحقيقي، سيتم استخدام رابط مشاركة البريد الإلكتروني
  };

  // حفظ في الجهاز
  const saveToDevice = () => {
    alert('تم حفظ التصميم في الجهاز');
    // في التطبيق الحقيقي، سيتم تنفيذ عملية الحفظ
  };

  // جدولة الإرسال
  const scheduleShare = () => {
    if (!scheduleDate || !scheduleTime || !recipient) {
      alert('يرجى ملء جميع الحقول المطلوبة');
      return;
    }
    
    alert(`تمت جدولة إرسال "${designTitle}" إلى ${recipient} في ${scheduleDate} الساعة ${scheduleTime}`);
    setShowShareOptions(false);
    setScheduleMode(false);
  };

  return (
    <div className="share-feature">
      <button className="share-button" onClick={toggleShareOptions}>
        مشاركة التصميم
      </button>
      
      {showShareOptions && (
        <div className="share-options">
          <h3>مشاركة "{designTitle}"</h3>
          
          {!scheduleMode ? (
            <>
              <div className="share-platforms">
                <button className="platform-button whatsapp" onClick={shareViaWhatsApp}>
                  <span className="platform-icon">📱</span>
                  <span>واتساب</span>
                </button>
                
                <button className="platform-button instagram" onClick={shareViaInstagram}>
                  <span className="platform-icon">📷</span>
                  <span>إنستغرام</span>
                </button>
                
                <button className="platform-button email" onClick={shareViaEmail}>
                  <span className="platform-icon">✉️</span>
                  <span>بريد إلكتروني</span>
                </button>
                
                <button className="platform-button save" onClick={saveToDevice}>
                  <span className="platform-icon">💾</span>
                  <span>حفظ</span>
                </button>
              </div>
              
              <button className="schedule-toggle" onClick={toggleScheduleMode}>
                جدولة الإرسال
              </button>
            </>
          ) : (
            <div className="schedule-form">
              <div className="form-group">
                <label>تاريخ الإرسال:</label>
                <input 
                  type="date" 
                  value={scheduleDate} 
                  onChange={(e) => setScheduleDate(e.target.value)} 
                />
              </div>
              
              <div className="form-group">
                <label>وقت الإرسال:</label>
                <input 
                  type="time" 
                  value={scheduleTime} 
                  onChange={(e) => setScheduleTime(e.target.value)} 
                />
              </div>
              
              <div className="form-group">
                <label>إرسال إلى:</label>
                <input 
                  type="text" 
                  placeholder="رقم الهاتف أو البريد الإلكتروني" 
                  value={recipient} 
                  onChange={(e) => setRecipient(e.target.value)} 
                />
              </div>
              
              <div className="schedule-actions">
                <button className="schedule-submit" onClick={scheduleShare}>
                  تأكيد الجدولة
                </button>
                
                <button className="schedule-cancel" onClick={toggleScheduleMode}>
                  إلغاء
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ShareFeature;
