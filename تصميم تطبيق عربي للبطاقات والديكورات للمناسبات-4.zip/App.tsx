import React from 'react';
import './App.css';

// الصفحة الرئيسية للتطبيق
const HomePage = () => {
  return (
    <div className="main-content">
      <div className="section-card">
        <img src="https://via.placeholder.com/400x180/FFD1DC/333333?text=بطاقات+التهنئة" alt="بطاقات التهنئة" />
        <div className="section-card-content">
          <h2>بطاقات التهنئة</h2>
          <p>صمم بطاقات تهنئة مميزة لجميع المناسبات مع إمكانية التخصيص الكامل</p>
          <button className="button">استكشف الآن</button>
        </div>
      </div>

      <div className="section-card">
        <img src="https://via.placeholder.com/400x180/BFEAF5/333333?text=تصاميم+الستوري" alt="تصاميم الستوري" />
        <div className="section-card-content">
          <h2>تصاميم الستوري</h2>
          <p>تصاميم ستوري مناسبة لإنستغرام وواتساب وسناب مع تأثيرات متحركة</p>
          <button className="button">استكشف الآن</button>
        </div>
      </div>

      <div className="section-card">
        <img src="https://via.placeholder.com/400x180/D0F0C0/333333?text=بطاقات+الأفراح" alt="بطاقات الأفراح" />
        <div className="section-card-content">
          <h2>بطاقات الأفراح</h2>
          <p>بطاقات دعوة فاخرة بصيغة رقمية مع تخصيص كامل للأسماء والتفاصيل</p>
          <button className="button">استكشف الآن</button>
        </div>
      </div>

      <div className="section-card">
        <img src="https://via.placeholder.com/400x180/E6E6FA/333333?text=الإكسسوارات" alt="الإكسسوارات" />
        <div className="section-card-content">
          <h2>الإكسسوارات</h2>
          <p>تسوق هدايا تذكارية وإكسسوارات مميزة للمناسبات والأفراح</p>
          <button className="button">استكشف الآن</button>
        </div>
      </div>
    </div>
  );
};

// قسم بطاقات التهنئة
const GreetingCardsSection = () => {
  return (
    <div className="main-content">
      <h1>بطاقات التهنئة</h1>
      
      <div className="category-pills">
        <div className="category-pill active">الكل</div>
        <div className="category-pill">أعياد الميلاد</div>
        <div className="category-pill">النجاح</div>
        <div className="category-pill">الزواج</div>
        <div className="category-pill">رمضان والعيد</div>
        <div className="category-pill">المواليد الجدد</div>
      </div>
      
      <div className="greeting-cards-grid">
        <div className="card-item">
          <img src="https://via.placeholder.com/200x120/FFD1DC/333333?text=عيد+ميلاد" alt="بطاقة عيد ميلاد" />
          <div className="card-item-content">
            <h3>بطاقة عيد ميلاد</h3>
            <button className="button">تخصيص</button>
          </div>
        </div>
        
        <div className="card-item">
          <img src="https://via.placeholder.com/200x120/BFEAF5/333333?text=نجاح" alt="بطاقة نجاح" />
          <div className="card-item-content">
            <h3>بطاقة نجاح</h3>
            <button className="button">تخصيص</button>
          </div>
        </div>
        
        <div className="card-item">
          <img src="https://via.placeholder.com/200x120/D0F0C0/333333?text=رمضان" alt="بطاقة رمضان" />
          <div className="card-item-content">
            <h3>بطاقة رمضان</h3>
            <button className="button">تخصيص</button>
          </div>
        </div>
        
        <div className="card-item">
          <img src="https://via.placeholder.com/200x120/E6E6FA/333333?text=مولود+جديد" alt="بطاقة مولود جديد" />
          <div className="card-item-content">
            <h3>بطاقة مولود جديد</h3>
            <button className="button">تخصيص</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// قسم تصاميم الستوري
const StoryDesignsSection = () => {
  return (
    <div className="main-content">
      <h1>تصاميم الستوري</h1>
      
      <div className="category-pills">
        <div className="category-pill active">الكل</div>
        <div className="category-pill">إنستغرام</div>
        <div className="category-pill">واتساب</div>
        <div className="category-pill">سناب</div>
        <div className="category-pill">متحركة</div>
      </div>
      
      <div className="story-designs-scroll">
        <div className="story-item">
          <img src="https://via.placeholder.com/120x200/FFD1DC/333333?text=ستوري+1" alt="ستوري 1" />
          <div className="story-item-content">
            <h3>ستوري عيد ميلاد</h3>
            <button className="button">تخصيص</button>
          </div>
        </div>
        
        <div className="story-item">
          <img src="https://via.placeholder.com/120x200/BFEAF5/333333?text=ستوري+2" alt="ستوري 2" />
          <div className="story-item-content">
            <h3>ستوري رمضان</h3>
            <button className="button">تخصيص</button>
          </div>
        </div>
        
        <div className="story-item">
          <img src="https://via.placeholder.com/120x200/D0F0C0/333333?text=ستوري+3" alt="ستوري 3" />
          <div className="story-item-content">
            <h3>ستوري العيد</h3>
            <button className="button">تخصيص</button>
          </div>
        </div>
        
        <div className="story-item">
          <img src="https://via.placeholder.com/120x200/E6E6FA/333333?text=ستوري+4" alt="ستوري 4" />
          <div className="story-item-content">
            <h3>ستوري نجاح</h3>
            <button className="button">تخصيص</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// قسم بطاقات الأفراح
const WeddingCardsSection = () => {
  return (
    <div className="main-content">
      <h1>بطاقات الأفراح</h1>
      
      <div className="category-pills">
        <div className="category-pill active">الكل</div>
        <div className="category-pill">كلاسيكي</div>
        <div className="category-pill">بوهيمي</div>
        <div className="category-pill">عصري</div>
        <div className="category-pill">فاخر</div>
      </div>
      
      <div className="wedding-cards-grid">
        <div className="wedding-card-item">
          <img src="https://via.placeholder.com/400x200/FFD1DC/333333?text=بطاقة+زفاف+كلاسيكية" alt="بطاقة زفاف كلاسيكية" />
          <div className="wedding-card-item-content">
            <h3>بطاقة زفاف كلاسيكية</h3>
            <p>بطاقة دعوة فاخرة بتصميم كلاسيكي مع زخارف عربية أصيلة</p>
            <button className="button">تخصيص</button>
          </div>
        </div>
        
        <div className="wedding-card-item">
          <img src="https://via.placeholder.com/400x200/BFEAF5/333333?text=بطاقة+زفاف+عصرية" alt="بطاقة زفاف عصرية" />
          <div className="wedding-card-item-content">
            <h3>بطاقة زفاف عصرية</h3>
            <p>بطاقة دعوة بتصميم عصري أنيق مع ألوان متناسقة</p>
            <button className="button">تخصيص</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// قسم الإكسسوارات
const AccessoriesSection = () => {
  return (
    <div className="main-content">
      <h1>الإكسسوارات</h1>
      
      <div className="category-pills">
        <div className="category-pill active">الكل</div>
        <div className="category-pill">هدايا تذكارية</div>
        <div className="category-pill">صناديق وعلب</div>
        <div className="category-pill">بطاقات مطبوعة</div>
        <div className="category-pill">ديكورات</div>
      </div>
      
      <div className="accessories-grid">
        <div className="accessory-item">
          <img src="https://via.placeholder.com/200x120/FFD1DC/333333?text=هدية+تذكارية" alt="هدية تذكارية" />
          <div className="accessory-item-content">
            <h3>هدية تذكارية للضيوف</h3>
            <p className="price">٥٠ ريال</p>
            <button className="button">طلب</button>
          </div>
        </div>
        
        <div className="accessory-item">
          <img src="https://via.placeholder.com/200x120/BFEAF5/333333?text=صندوق+هدايا" alt="صندوق هدايا" />
          <div className="accessory-item-content">
            <h3>صندوق هدايا فاخر</h3>
            <p className="price">١٢٠ ريال</p>
            <button className="button">طلب</button>
          </div>
        </div>
        
        <div className="accessory-item">
          <img src="https://via.placeholder.com/200x120/D0F0C0/333333?text=بطاقات+مطبوعة" alt="بطاقات مطبوعة" />
          <div className="accessory-item-content">
            <h3>بطاقات شكر مطبوعة</h3>
            <p className="price">٨٠ ريال</p>
            <button className="button">طلب</button>
          </div>
        </div>
        
        <div className="accessory-item">
          <img src="https://via.placeholder.com/200x120/E6E6FA/333333?text=ديكورات" alt="ديكورات" />
          <div className="accessory-item-content">
            <h3>ديكورات طاولة</h3>
            <p className="price">١٥٠ ريال</p>
            <button className="button">طلب</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// مكون شريط التنقل
const NavBar = () => {
  return (
    <div className="nav-bar">
      <div className="nav-item">
        <div className="nav-icon">🏠</div>
        <span>الرئيسية</span>
      </div>
      <div className="nav-item">
        <div className="nav-icon">🎁</div>
        <span>البطاقات</span>
      </div>
      <div className="nav-item">
        <div className="nav-icon">📱</div>
        <span>الستوري</span>
      </div>
      <div className="nav-item">
        <div className="nav-icon">💍</div>
        <span>الأفراح</span>
      </div>
      <div className="nav-item">
        <div className="nav-icon">🛍️</div>
        <span>الإكسسوارات</span>
      </div>
    </div>
  );
};

// التطبيق الرئيسي
function App() {
  return (
    <div className="app-container">
      <header className="header">
        <div className="logo">صمّم لحظتك</div>
        <div>
          <span style={{ marginLeft: '1rem' }}>⚙️</span>
          <span>🔔</span>
        </div>
      </header>
      
      {/* عرض الصفحة الرئيسية كافتراضي */}
      <HomePage />
      
      {/* يمكن تبديل المكونات حسب الصفحة المطلوبة */}
      {/* <GreetingCardsSection /> */}
      {/* <StoryDesignsSection /> */}
      {/* <WeddingCardsSection /> */}
      {/* <AccessoriesSection /> */}
      
      <NavBar />
    </div>
  );
}

export default App;
