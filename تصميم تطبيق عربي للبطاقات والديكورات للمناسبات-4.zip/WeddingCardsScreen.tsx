import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image, FlatList } from 'react-native';
import { useTheme } from 'react-native-paper';
import i18n from '../localization/i18n';

// Placeholder for images - in a real app, these would be actual image assets
const PLACEHOLDER_IMAGE = 'https://via.placeholder.com/150';

// Categories for wedding cards
const CATEGORIES = [
  { id: '1', name: i18n.t('classic') },
  { id: '2', name: i18n.t('modern') },
  { id: '3', name: i18n.t('bohemian') },
];

// Sample wedding cards data
const WEDDING_CARDS = [
  { id: '1', title: 'بطاقة زفاف كلاسيكية 1', category: '1', image: PLACEHOLDER_IMAGE },
  { id: '2', title: 'بطاقة زفاف كلاسيكية 2', category: '1', image: PLACEHOLDER_IMAGE },
  { id: '3', title: 'بطاقة زفاف عصرية 1', category: '2', image: PLACEHOLDER_IMAGE },
  { id: '4', title: 'بطاقة زفاف عصرية 2', category: '2', image: PLACEHOLDER_IMAGE },
  { id: '5', title: 'بطاقة زفاف بوهيمية 1', category: '3', image: PLACEHOLDER_IMAGE },
  { id: '6', title: 'بطاقة زفاف بوهيمية 2', category: '3', image: PLACEHOLDER_IMAGE },
];

const WeddingCardsScreen = ({ navigation }: any) => {
  const theme = useTheme();
  const [selectedCategory, setSelectedCategory] = React.useState('all');

  const filteredCards = selectedCategory === 'all' 
    ? WEDDING_CARDS 
    : WEDDING_CARDS.filter(card => card.category === selectedCategory);

  const renderCardItem = ({ item }: { item: { id: string, title: string, category: string, image: string } }) => (
    <TouchableOpacity
      style={styles.cardItem}
      onPress={() => navigation.navigate('WeddingCardEditor', { card: item })}
    >
      <Image source={{ uri: item.image }} style={styles.cardImage} />
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardCategory}>
          {CATEGORIES.find(cat => cat.id === item.category)?.name || ''}
        </Text>
      </View>
      <View style={styles.cardActions}>
        <TouchableOpacity style={styles.actionButton}>
          <Text style={styles.actionButtonText}>تخصيص</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionButton, styles.previewButton]}>
          <Text style={styles.actionButtonText}>معاينة</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{i18n.t('weddingCards')}</Text>
      </View>

      <View style={styles.categoriesContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesScrollContent}
        >
          <TouchableOpacity
            style={[
              styles.categoryItem,
              selectedCategory === 'all' && { backgroundColor: '#FFD1DC' }
            ]}
            onPress={() => setSelectedCategory('all')}
          >
            <Text style={[
              styles.categoryText,
              selectedCategory === 'all' && { color: '#333' }
            ]}>
              الكل
            </Text>
          </TouchableOpacity>
          
          {CATEGORIES.map(category => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryItem,
                selectedCategory === category.id && { backgroundColor: '#FFD1DC' }
              ]}
              onPress={() => setSelectedCategory(category.id)}
            >
              <Text style={[
                styles.categoryText,
                selectedCategory === category.id && { color: '#333' }
              ]}>
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filteredCards}
        renderItem={renderCardItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.cardsContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8FA', // Light pink background
  },
  header: {
    padding: 15,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#D4AF37', // Gold color
  },
  categoriesContainer: {
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  categoriesScrollContent: {
    paddingHorizontal: 15,
  },
  categoryItem: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginRight: 10,
  },
  categoryText: {
    fontSize: 14,
    color: '#666',
  },
  cardsContainer: {
    padding: 10,
  },
  cardItem: {
    marginBottom: 15,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  cardImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  cardContent: {
    padding: 12,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  cardCategory: {
    fontSize: 14,
    color: '#888',
  },
  cardActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  actionButton: {
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
    backgroundColor: '#FFD1DC',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    marginHorizontal: 5,
  },
  previewButton: {
    backgroundColor: '#D4AF37',
  },
  actionButtonText: {
    color: '#333',
    fontWeight: 'bold',
    fontSize: 14,
  },
});

export default WeddingCardsScreen;
