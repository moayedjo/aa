import React, { useState } from 'react';
import './CardEditor.css';

// مكون محرر البطاقات
const CardEditor = () => {
  const [elements, setElements] = useState([]);
  const [selectedElement, setSelectedElement] = useState(null);
  const [text, setText] = useState('');
  const [fontSize, setFontSize] = useState(16);
  const [fontColor, setFontColor] = useState('#000000');
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  // إضافة عنصر نص جديد
  const addTextElement = () => {
    const newElement = {
      id: Date.now(),
      type: 'text',
      content: 'أدخل النص هنا',
      x: 100,
      y: 100,
      fontSize: 16,
      color: '#000000',
    };
    setElements([...elements, newElement]);
    setSelectedElement(newElement.id);
  };

  // إضافة عنصر صورة
  const addImageElement = (imageUrl) => {
    const newElement = {
      id: Date.now(),
      type: 'image',
      src: imageUrl,
      x: 100,
      y: 100,
      width: 100,
      height: 100,
    };
    setElements([...elements, newElement]);
    setSelectedElement(newElement.id);
  };

  // إضافة عنصر زخرفة
  const addDecorationElement = (decorationUrl) => {
    const newElement = {
      id: Date.now(),
      type: 'decoration',
      src: decorationUrl,
      x: 100,
      y: 100,
      width: 50,
      height: 50,
    };
    setElements([...elements, newElement]);
    setSelectedElement(newElement.id);
  };

  // بدء السحب
  const handleDragStart = (e, id) => {
    setIsDragging(true);
    setSelectedElement(id);
    
    const element = elements.find(el => el.id === id);
    const rect = e.target.getBoundingClientRect();
    
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
  };

  // أثناء السحب
  const handleDrag = (e) => {
    if (isDragging && selectedElement) {
      const updatedElements = elements.map(el => {
        if (el.id === selectedElement) {
          return {
            ...el,
            x: e.clientX - dragOffset.x,
            y: e.clientY - dragOffset.y
          };
        }
        return el;
      });
      setElements(updatedElements);
    }
  };

  // إنهاء السحب
  const handleDragEnd = () => {
    setIsDragging(false);
  };

  // تحديث محتوى النص
  const updateTextContent = (id, content) => {
    const updatedElements = elements.map(el => {
      if (el.id === id) {
        return { ...el, content };
      }
      return el;
    });
    setElements(updatedElements);
  };

  // تحديث حجم الخط
  const updateFontSize = (id, size) => {
    const updatedElements = elements.map(el => {
      if (el.id === id && el.type === 'text') {
        return { ...el, fontSize: size };
      }
      return el;
    });
    setElements(updatedElements);
  };

  // تحديث لون الخط
  const updateFontColor = (id, color) => {
    const updatedElements = elements.map(el => {
      if (el.id === id && el.type === 'text') {
        return { ...el, color };
      }
      return el;
    });
    setElements(updatedElements);
  };

  // حذف عنصر
  const deleteElement = (id) => {
    const updatedElements = elements.filter(el => el.id !== id);
    setElements(updatedElements);
    setSelectedElement(null);
  };

  // حفظ التصميم
  const saveDesign = () => {
    // هنا يمكن إضافة منطق الحفظ
    console.log('تم حفظ التصميم', elements);
    alert('تم حفظ التصميم بنجاح!');
  };

  // مشاركة التصميم
  const shareDesign = () => {
    // هنا يمكن إضافة منطق المشاركة
    console.log('تمت مشاركة التصميم', elements);
    alert('تم فتح خيارات المشاركة!');
  };

  return (
    <div className="card-editor">
      <div className="editor-sidebar">
        <div className="tools-section">
          <h3>الأدوات</h3>
          <button onClick={addTextElement}>إضافة نص</button>
          <button onClick={() => addImageElement('https://via.placeholder.com/100')}>إضافة صورة</button>
          <button onClick={() => addDecorationElement('https://via.placeholder.com/50/FFD1DC/000000?text=★')}>إضافة زخرفة</button>
        </div>
        
        {selectedElement && (
          <div className="properties-section">
            <h3>الخصائص</h3>
            {elements.find(el => el.id === selectedElement)?.type === 'text' && (
              <>
                <div className="property">
                  <label>النص:</label>
                  <input 
                    type="text" 
                    value={elements.find(el => el.id === selectedElement)?.content || ''} 
                    onChange={(e) => updateTextContent(selectedElement, e.target.value)} 
                  />
                </div>
                <div className="property">
                  <label>حجم الخط:</label>
                  <input 
                    type="range" 
                    min="10" 
                    max="40" 
                    value={elements.find(el => el.id === selectedElement)?.fontSize || 16} 
                    onChange={(e) => updateFontSize(selectedElement, parseInt(e.target.value))} 
                  />
                </div>
                <div className="property">
                  <label>لون الخط:</label>
                  <input 
                    type="color" 
                    value={elements.find(el => el.id === selectedElement)?.color || '#000000'} 
                    onChange={(e) => updateFontColor(selectedElement, e.target.value)} 
                  />
                </div>
              </>
            )}
            <button className="delete-button" onClick={() => deleteElement(selectedElement)}>حذف العنصر</button>
          </div>
        )}
      </div>
      
      <div 
        className="canvas-area"
        onMouseMove={handleDrag}
        onMouseUp={handleDragEnd}
      >
        <div className="canvas">
          {elements.map((element) => (
            <div
              key={element.id}
              className={`canvas-element ${element.type} ${selectedElement === element.id ? 'selected' : ''}`}
              style={{
                left: `${element.x}px`,
                top: `${element.y}px`,
                fontSize: element.type === 'text' ? `${element.fontSize}px` : undefined,
                color: element.type === 'text' ? element.color : undefined,
                width: element.type !== 'text' ? `${element.width}px` : undefined,
                height: element.type !== 'text' ? `${element.height}px` : undefined,
              }}
              onMouseDown={(e) => handleDragStart(e, element.id)}
            >
              {element.type === 'text' && element.content}
              {element.type === 'image' && <img src={element.src} alt="صورة" />}
              {element.type === 'decoration' && <img src={element.src} alt="زخرفة" />}
            </div>
          ))}
        </div>
      </div>
      
      <div className="editor-actions">
        <button className="save-button" onClick={saveDesign}>حفظ التصميم</button>
        <button className="share-button" onClick={shareDesign}>مشاركة</button>
      </div>
    </div>
  );
};

export default CardEditor;
