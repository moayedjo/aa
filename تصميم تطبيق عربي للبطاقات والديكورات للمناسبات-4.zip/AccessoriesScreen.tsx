import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image, FlatList } from 'react-native';
import { useTheme } from 'react-native-paper';
import i18n from '../localization/i18n';

// Placeholder for images - in a real app, these would be actual image assets
const PLACEHOLDER_IMAGE = 'https://via.placeholder.com/150';

// Categories for accessories
const CATEGORIES = [
  { id: '1', name: i18n.t('gifts') },
  { id: '2', name: i18n.t('decorations') },
  { id: '3', name: i18n.t('printedCards') },
];

// Sample accessories data
const ACCESSORIES = [
  { id: '1', title: 'صندوق هدايا فاخر', category: '1', price: '120 ر.س', image: PLACEHOLDER_IMAGE },
  { id: '2', title: 'علبة هدية مزخرفة', category: '1', price: '85 ر.س', image: PLACEHOLDER_IMAGE },
  { id: '3', title: 'زينة أفراح ذهبية', category: '2', price: '150 ر.س', image: PLACEHOLDER_IMAGE },
  { id: '4', title: 'ديكور طاولة العروسين', category: '2', price: '200 ر.س', image: PLACEHOLDER_IMAGE },
  { id: '5', title: 'بطاقات مطبوعة فاخرة', category: '3', price: '5 ر.س / قطعة', image: PLACEHOLDER_IMAGE },
  { id: '6', title: 'بطاقات شكر للضيوف', category: '3', price: '3 ر.س / قطعة', image: PLACEHOLDER_IMAGE },
];

const AccessoriesScreen = ({ navigation }: any) => {
  const theme = useTheme();
  const [selectedCategory, setSelectedCategory] = React.useState('all');

  const filteredAccessories = selectedCategory === 'all' 
    ? ACCESSORIES 
    : ACCESSORIES.filter(accessory => accessory.category === selectedCategory);

  const renderAccessoryItem = ({ item }: { item: { id: string, title: string, category: string, price: string, image: string } }) => (
    <TouchableOpacity
      style={styles.accessoryItem}
      onPress={() => navigation.navigate('AccessoryDetails', { accessory: item })}
    >
      <Image source={{ uri: item.image }} style={styles.accessoryImage} />
      <View style={styles.accessoryContent}>
        <Text style={styles.accessoryTitle}>{item.title}</Text>
        <Text style={styles.accessoryCategory}>
          {CATEGORIES.find(cat => cat.id === item.category)?.name || ''}
        </Text>
        <Text style={styles.accessoryPrice}>{item.price}</Text>
      </View>
      <View style={styles.accessoryActions}>
        <TouchableOpacity style={styles.actionButton}>
          <Text style={styles.actionButtonText}>طلب</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionButton, styles.detailsButton]}>
          <Text style={styles.actionButtonText}>التفاصيل</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{i18n.t('accessories')}</Text>
      </View>

      <View style={styles.categoriesContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesScrollContent}
        >
          <TouchableOpacity
            style={[
              styles.categoryItem,
              selectedCategory === 'all' && { backgroundColor: '#FFD1DC' }
            ]}
            onPress={() => setSelectedCategory('all')}
          >
            <Text style={[
              styles.categoryText,
              selectedCategory === 'all' && { color: '#333' }
            ]}>
              الكل
            </Text>
          </TouchableOpacity>
          
          {CATEGORIES.map(category => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryItem,
                selectedCategory === category.id && { backgroundColor: '#FFD1DC' }
              ]}
              onPress={() => setSelectedCategory(category.id)}
            >
              <Text style={[
                styles.categoryText,
                selectedCategory === category.id && { color: '#333' }
              ]}>
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filteredAccessories}
        renderItem={renderAccessoryItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.accessoriesContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8FA', // Light pink background
  },
  header: {
    padding: 15,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#D4AF37', // Gold color
  },
  categoriesContainer: {
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  categoriesScrollContent: {
    paddingHorizontal: 15,
  },
  categoryItem: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginRight: 10,
  },
  categoryText: {
    fontSize: 14,
    color: '#666',
  },
  accessoriesContainer: {
    padding: 10,
  },
  accessoryItem: {
    marginBottom: 15,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  accessoryImage: {
    width: '100%',
    height: 180,
    resizeMode: 'cover',
  },
  accessoryContent: {
    padding: 12,
  },
  accessoryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  accessoryCategory: {
    fontSize: 14,
    color: '#888',
    marginBottom: 5,
  },
  accessoryPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#D4AF37',
  },
  accessoryActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  actionButton: {
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
    backgroundColor: '#FFD1DC',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    marginHorizontal: 5,
  },
  detailsButton: {
    backgroundColor: '#BFEAF5', // Pastel blue
  },
  actionButtonText: {
    color: '#333',
    fontWeight: 'bold',
    fontSize: 14,
  },
});

export default AccessoriesScreen;
