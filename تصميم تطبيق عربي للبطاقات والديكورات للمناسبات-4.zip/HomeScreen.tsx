import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import { useTheme } from 'react-native-paper';
import i18n from '../localization/i18n';

// Placeholder for images - in a real app, these would be actual image assets
const PLACEHOLDER_IMAGE = 'https://via.placeholder.com/150';

const HomeScreen = ({ navigation }: any) => {
  const theme = useTheme();

  const renderSectionCard = (title: string, image: string, onPress: () => void) => (
    <TouchableOpacity 
      style={[styles.sectionCard, { backgroundColor: theme.colors.background }]} 
      onPress={onPress}
    >
      <Image source={{ uri: image }} style={styles.sectionImage} />
      <View style={styles.sectionContent}>
        <Text style={styles.sectionTitle}>{title}</Text>
      </View>
    </TouchableOpacity>
  );

  const renderRecentDesign = (title: string, category: string, image: string, onPress: () => void) => (
    <TouchableOpacity 
      style={[styles.recentDesignCard, { backgroundColor: theme.colors.background }]} 
      onPress={onPress}
    >
      <Image source={{ uri: image }} style={styles.recentDesignImage} />
      <View style={styles.recentDesignContent}>
        <Text style={styles.recentDesignTitle}>{title}</Text>
        <Text style={styles.recentDesignCategory}>{category}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.appName}>{i18n.t('appName')}</Text>
      </View>
      
      <Text style={styles.sectionHeader}>{i18n.t('exploreDesigns')}</Text>
      
      <View style={styles.mainSections}>
        {renderSectionCard(
          i18n.t('greetingCards'), 
          PLACEHOLDER_IMAGE, 
          () => navigation.navigate('GreetingCards')
        )}
        
        {renderSectionCard(
          i18n.t('storyDesigns'), 
          PLACEHOLDER_IMAGE, 
          () => navigation.navigate('StoryDesigns')
        )}
        
        {renderSectionCard(
          i18n.t('weddingCards'), 
          PLACEHOLDER_IMAGE, 
          () => navigation.navigate('WeddingCards')
        )}
        
        {renderSectionCard(
          i18n.t('accessories'), 
          PLACEHOLDER_IMAGE, 
          () => navigation.navigate('Accessories')
        )}
      </View>
      
      <Text style={styles.sectionHeader}>{i18n.t('recentDesigns')}</Text>
      
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.recentDesignsScroll}>
        {renderRecentDesign(
          'تهنئة عيد ميلاد', 
          i18n.t('birthday'), 
          PLACEHOLDER_IMAGE, 
          () => {}
        )}
        
        {renderRecentDesign(
          'ستوري رمضان', 
          i18n.t('ramadan'), 
          PLACEHOLDER_IMAGE, 
          () => {}
        )}
        
        {renderRecentDesign(
          'بطاقة زفاف', 
          i18n.t('weddingCards'), 
          PLACEHOLDER_IMAGE, 
          () => {}
        )}
        
        {renderRecentDesign(
          'تهنئة مولود جديد', 
          i18n.t('newBaby'), 
          PLACEHOLDER_IMAGE, 
          () => {}
        )}
      </ScrollView>
      
      <Text style={styles.sectionHeader}>{i18n.t('popularTemplates')}</Text>
      
      <View style={styles.popularTemplates}>
        {renderRecentDesign(
          'قالب كلاسيكي', 
          i18n.t('classic'), 
          PLACEHOLDER_IMAGE, 
          () => {}
        )}
        
        {renderRecentDesign(
          'قالب عصري', 
          i18n.t('modern'), 
          PLACEHOLDER_IMAGE, 
          () => {}
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8FA', // Light pink background
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  appName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#D4AF37', // Gold color
    marginBottom: 10,
  },
  sectionHeader: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    padding: 15,
    paddingBottom: 10,
  },
  mainSections: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    padding: 10,
  },
  sectionCard: {
    width: '48%',
    borderRadius: 15,
    overflow: 'hidden',
    marginBottom: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionImage: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  sectionContent: {
    padding: 10,
    alignItems: 'center',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  recentDesignsScroll: {
    paddingHorizontal: 10,
  },
  recentDesignCard: {
    width: 150,
    borderRadius: 12,
    overflow: 'hidden',
    marginHorizontal: 5,
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  recentDesignImage: {
    width: '100%',
    height: 100,
    resizeMode: 'cover',
  },
  recentDesignContent: {
    padding: 8,
  },
  recentDesignTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  recentDesignCategory: {
    fontSize: 12,
    color: '#888',
    marginTop: 2,
  },
  popularTemplates: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    padding: 10,
    paddingBottom: 20,
  },
});

export default HomeScreen;
