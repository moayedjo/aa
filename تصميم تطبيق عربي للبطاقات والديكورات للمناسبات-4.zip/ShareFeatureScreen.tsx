import React, { useState } from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image, Share, Alert } from 'react-native';
import { useTheme } from 'react-native-paper';
import i18n from '../localization/i18n';

const ShareFeatureScreen = ({ route, navigation }: any) => {
  const theme = useTheme();
  const { design } = route.params || { design: { id: '1', title: 'تصميم جديد', image: 'https://via.placeholder.com/150' } };
  
  const [selectedPlatform, setSelectedPlatform] = useState(null);
  
  const platforms = [
    { id: 'whatsapp', name: 'واتساب', icon: 'https://via.placeholder.com/50' },
    { id: 'instagram', name: 'إنستغرام', icon: 'https://via.placeholder.com/50' },
    { id: 'email', name: 'البريد الإلكتروني', icon: 'https://via.placeholder.com/50' },
    { id: 'save', name: 'حفظ على الجهاز', icon: 'https://via.placeholder.com/50' },
  ];

  const handleShare = async () => {
    if (!selectedPlatform) {
      Alert.alert('تنبيه', 'الرجاء اختيار منصة للمشاركة');
      return;
    }

    try {
      if (selectedPlatform === 'save') {
        // In a real app, this would save the image to the device gallery
        Alert.alert('نجاح', 'تم حفظ التصميم على الجهاز');
        return;
      }

      const result = await Share.share({
        message: `شارك تصميمك: ${design.title}`,
        // In a real app, this would be the actual URL of the design
        url: design.image,
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
          console.log(result.activityType);
        } else {
          // shared
          console.log('shared');
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
        console.log('dismissed');
      }
    } catch (error) {
      Alert.alert('خطأ', error.message);
    }
  };

  const handleSchedule = () => {
    navigation.navigate('ScheduleShare', { design });
  };

  const handleSaveToFavorites = () => {
    // In a real app, this would save the design to favorites in local storage
    Alert.alert('نجاح', 'تم حفظ التصميم في المفضلة');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{i18n.t('shareVia')}</Text>
      </View>

      <View style={styles.designPreview}>
        <Image source={{ uri: design.image }} style={styles.designImage} />
        <Text style={styles.designTitle}>{design.title}</Text>
      </View>

      <Text style={styles.sectionTitle}>اختر منصة المشاركة</Text>

      <View style={styles.platformsGrid}>
        {platforms.map(platform => (
          <TouchableOpacity
            key={platform.id}
            style={[
              styles.platformItem,
              selectedPlatform === platform.id && styles.selectedPlatformItem
            ]}
            onPress={() => setSelectedPlatform(platform.id)}
          >
            <Image source={{ uri: platform.icon }} style={styles.platformIcon} />
            <Text style={styles.platformName}>{platform.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.actionsContainer}>
        <TouchableOpacity style={styles.actionButton} onPress={handleShare}>
          <Text style={styles.actionButtonText}>{i18n.t('share')}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.actionButton, styles.scheduleButton]} onPress={handleSchedule}>
          <Text style={styles.actionButtonText}>{i18n.t('schedule')}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.actionButton, styles.favoriteButton]} onPress={handleSaveToFavorites}>
          <Text style={styles.actionButtonText}>{i18n.t('saveToFavorites')}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8FA',
  },
  header: {
    padding: 15,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#D4AF37',
  },
  designPreview: {
    alignItems: 'center',
    padding: 20,
  },
  designImage: {
    width: 200,
    height: 300,
    borderRadius: 10,
    marginBottom: 10,
  },
  designTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    padding: 15,
    textAlign: 'right',
  },
  platformsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    padding: 10,
  },
  platformItem: {
    width: '45%',
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#fff',
    alignItems: 'center',
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  selectedPlatformItem: {
    backgroundColor: '#FFD1DC',
  },
  platformIcon: {
    width: 50,
    height: 50,
    marginBottom: 10,
  },
  platformName: {
    fontSize: 14,
    color: '#333',
  },
  actionsContainer: {
    padding: 20,
  },
  actionButton: {
    paddingVertical: 12,
    borderRadius: 25,
    backgroundColor: '#FFD1DC',
    alignItems: 'center',
    marginBottom: 10,
  },
  scheduleButton: {
    backgroundColor: '#BFEAF5',
  },
  favoriteButton: {
    backgroundColor: '#D4AF37',
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default ShareFeatureScreen;
