import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image, FlatList } from 'react-native';
import { useTheme } from 'react-native-paper';
import i18n from '../localization/i18n';

// Placeholder for images - in a real app, these would be actual image assets
const PLACEHOLDER_IMAGE = 'https://via.placeholder.com/150';

// Categories for greeting cards
const CATEGORIES = [
  { id: '1', name: i18n.t('birthday') },
  { id: '2', name: i18n.t('success') },
  { id: '3', name: i18n.t('ramadan') },
  { id: '4', name: i18n.t('eid') },
  { id: '5', name: i18n.t('newBaby') },
];

// Sample greeting cards data
const GREETING_CARDS = [
  { id: '1', title: 'بطاقة عيد ميلاد 1', category: 'birthday', image: PLACEHOLDER_IMAGE },
  { id: '2', title: 'بطاقة عيد ميلاد 2', category: 'birthday', image: PLACEHOLDER_IMAGE },
  { id: '3', title: 'بطاقة نجاح', category: 'success', image: PLACEHOLDER_IMAGE },
  { id: '4', title: 'بطاقة رمضان 1', category: 'ramadan', image: PLACEHOLDER_IMAGE },
  { id: '5', title: 'بطاقة رمضان 2', category: 'ramadan', image: PLACEHOLDER_IMAGE },
  { id: '6', title: 'بطاقة عيد 1', category: 'eid', image: PLACEHOLDER_IMAGE },
  { id: '7', title: 'بطاقة مولود جديد', category: 'newBaby', image: PLACEHOLDER_IMAGE },
];

const GreetingCardsScreen = ({ navigation }: any) => {
  const theme = useTheme();
  const [selectedCategory, setSelectedCategory] = React.useState('all');

  const filteredCards = selectedCategory === 'all' 
    ? GREETING_CARDS 
    : GREETING_CARDS.filter(card => card.category === selectedCategory);

  const renderCategoryItem = ({ item }: { item: { id: string, name: string } }) => (
    <TouchableOpacity
      style={[
        styles.categoryItem,
        selectedCategory === item.id && { backgroundColor: '#FFD1DC' }
      ]}
      onPress={() => setSelectedCategory(item.id)}
    >
      <Text style={[
        styles.categoryText,
        selectedCategory === item.id && { color: '#333' }
      ]}>
        {item.name}
      </Text>
    </TouchableOpacity>
  );

  const renderCardItem = ({ item }: { item: { id: string, title: string, category: string, image: string } }) => (
    <TouchableOpacity
      style={styles.cardItem}
      onPress={() => navigation.navigate('CardEditor', { card: item })}
    >
      <Image source={{ uri: item.image }} style={styles.cardImage} />
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardCategory}>
          {CATEGORIES.find(cat => cat.id === item.category)?.name || item.category}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{i18n.t('greetingCards')}</Text>
      </View>

      <View style={styles.categoriesContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesScrollContent}
        >
          <TouchableOpacity
            style={[
              styles.categoryItem,
              selectedCategory === 'all' && { backgroundColor: '#FFD1DC' }
            ]}
            onPress={() => setSelectedCategory('all')}
          >
            <Text style={[
              styles.categoryText,
              selectedCategory === 'all' && { color: '#333' }
            ]}>
              الكل
            </Text>
          </TouchableOpacity>
          
          {CATEGORIES.map(category => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryItem,
                selectedCategory === category.id && { backgroundColor: '#FFD1DC' }
              ]}
              onPress={() => setSelectedCategory(category.id)}
            >
              <Text style={[
                styles.categoryText,
                selectedCategory === category.id && { color: '#333' }
              ]}>
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filteredCards}
        renderItem={renderCardItem}
        keyExtractor={item => item.id}
        numColumns={2}
        contentContainerStyle={styles.cardsContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8FA', // Light pink background
  },
  header: {
    padding: 15,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#D4AF37', // Gold color
  },
  categoriesContainer: {
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  categoriesScrollContent: {
    paddingHorizontal: 15,
  },
  categoryItem: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginRight: 10,
  },
  categoryText: {
    fontSize: 14,
    color: '#666',
  },
  cardsContainer: {
    padding: 10,
  },
  cardItem: {
    flex: 1,
    margin: 5,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  cardImage: {
    width: '100%',
    height: 150,
    resizeMode: 'cover',
  },
  cardContent: {
    padding: 10,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  cardCategory: {
    fontSize: 12,
    color: '#888',
  },
});

export default GreetingCardsScreen;
