import * as Localization from 'expo-localization';
import { I18n } from 'i18n-js';
import { I18nManager } from 'react-native';

// Force RTL for Arabic
I18nManager.forceRTL(true);

// Translation object
const translations = {
  ar: {
    // General
    appName: 'بطاقات التهنئة',
    welcome: 'مرحباً بك في تطبيق بطاقات التهنئة',
    
    // Navigation
    home: 'الرئيسية',
    greetingCards: 'بطاقات التهنئة',
    storyDesigns: 'تصاميم ستوري',
    weddingCards: 'بطاقات أفراح',
    accessories: 'إكسسوارات',
    
    // Home Screen
    exploreDesigns: 'استكشف التصاميم',
    recentDesigns: 'تصاميم حديثة',
    popularTemplates: 'قوالب شائعة',
    
    // Greeting Cards
    birthday: 'أعياد الميلاد',
    success: 'النجاح',
    ramadan: 'رمضان',
    eid: 'العيد',
    newBaby: 'المواليد الجدد',
    
    // Story Designs
    instagram: 'إنستغرام',
    whatsapp: 'واتساب',
    snapchat: 'سناب شات',
    
    // Wedding Cards
    classic: 'كلاسيكي',
    modern: 'عصري',
    bohemian: 'بوهيمي',
    
    // Accessories
    gifts: 'هدايا',
    decorations: 'ديكورات',
    printedCards: 'بطاقات مطبوعة',
    
    // Editor
    edit: 'تعديل',
    save: 'حفظ',
    share: 'مشاركة',
    addText: 'إضافة نص',
    addImage: 'إضافة صورة',
    addSymbol: 'إضافة رمز',
    
    // Sharing
    shareVia: 'مشاركة عبر',
    schedule: 'جدولة',
    saveToFavorites: 'حفظ في المفضلة',
    
    // Favorites
    favorites: 'المفضلة',
    noFavorites: 'لا توجد تصاميم محفوظة',
    
    // Misc
    loading: 'جاري التحميل...',
    tryAgain: 'حاول مرة أخرى',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
  },
};

// Create i18n instance
const i18n = new I18n(translations);

// Set the locale once at the beginning of your app
i18n.locale = 'ar';
i18n.enableFallback = true;

export default i18n;
