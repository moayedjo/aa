import React, { useState, useRef } from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image, PanResponder, Animated, TextInput, Dimensions } from 'react-native';
import { useTheme } from 'react-native-paper';
import i18n from '../localization/i18n';

// Placeholder for images - in a real app, these would be actual image assets
const PLACEHOLDER_IMAGE = 'https://via.placeholder.com/150';

// Sample symbols and decorations
const SYMBOLS = [
  { id: '1', category: 'islamic', image: PLACEHOLDER_IMAGE },
  { id: '2', category: 'islamic', image: PLACEHOLDER_IMAGE },
  { id: '3', category: 'floral', image: PLACEHOLDER_IMAGE },
  { id: '4', category: 'floral', image: PLACEHOLDER_IMAGE },
  { id: '5', category: 'frames', image: PLACEHOLDER_IMAGE },
  { id: '6', category: 'frames', image: PLACEHOLDER_IMAGE },
];

// Sample fonts
const FONTS = [
  { id: '1', name: 'Cairo' },
  { id: '2', name: 'Noto Kufi Arabic' },
  { id: '3', name: 'Tajawal' },
];

// Sample colors
const COLORS = [
  { id: '1', value: '#FFD1DC' }, // Pink
  { id: '2', value: '#D4AF37' }, // Gold
  { id: '3', value: '#FFFFFF' }, // White
  { id: '4', value: '#FFF8F0' }, // Off-white
  { id: '5', value: '#BFEAF5' }, // Pastel blue
  { id: '6', value: '#D0F0C0' }, // Pastel green
];

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const CardEditorScreen = ({ route, navigation }: any) => {
  const theme = useTheme();
  const { card } = route.params || { card: { id: '1', title: 'بطاقة جديدة', category: 'birthday', image: PLACEHOLDER_IMAGE } };
  
  const [activeTab, setActiveTab] = useState('text');
  const [elements, setElements] = useState([
    { id: '1', type: 'background', image: card.image, x: 0, y: 0, width: SCREEN_WIDTH - 40, height: 400, zIndex: 0 },
    { id: '2', type: 'text', content: 'أضف نصاً هنا', x: 50, y: 100, fontSize: 24, color: '#000000', fontFamily: 'Cairo', zIndex: 1 },
  ]);
  const [selectedElement, setSelectedElement] = useState(null);
  const [textInputValue, setTextInputValue] = useState('');
  const [textInputVisible, setTextInputVisible] = useState(false);
  const [selectedFont, setSelectedFont] = useState(FONTS[0]);
  const [selectedColor, setSelectedColor] = useState(COLORS[0]);

  // Create animated values for each element
  const animatedValues = useRef({}).current;
  
  elements.forEach(element => {
    if (!animatedValues[element.id]) {
      animatedValues[element.id] = {
        x: new Animated.Value(element.x),
        y: new Animated.Value(element.y),
      };
    }
  });

  // Create pan responders for each element
  const panResponders = useRef({}).current;
  
  elements.forEach(element => {
    if (element.type !== 'background' && !panResponders[element.id]) {
      panResponders[element.id] = PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onPanResponderGrant: () => {
          setSelectedElement(element);
          // Update the animated values to match the current position
          animatedValues[element.id].x.setOffset(element.x);
          animatedValues[element.id].y.setOffset(element.y);
          animatedValues[element.id].x.setValue(0);
          animatedValues[element.id].y.setValue(0);
        },
        onPanResponderMove: Animated.event(
          [null, { dx: animatedValues[element.id].x, dy: animatedValues[element.id].y }],
          { useNativeDriver: false }
        ),
        onPanResponderRelease: () => {
          // Calculate the new position
          const newX = animatedValues[element.id].x._value + animatedValues[element.id].x._offset;
          const newY = animatedValues[element.id].y._value + animatedValues[element.id].y._offset;
          
          // Update the element's position
          setElements(prevElements => 
            prevElements.map(el => 
              el.id === element.id ? { ...el, x: newX, y: newY } : el
            )
          );
          
          // Reset the animated values
          animatedValues[element.id].x.flattenOffset();
          animatedValues[element.id].y.flattenOffset();
        },
      });
    }
  });

  const addTextElement = () => {
    const newElement = {
      id: `text-${Date.now()}`,
      type: 'text',
      content: 'نص جديد',
      x: 50,
      y: 150,
      fontSize: 24,
      color: selectedColor.value,
      fontFamily: selectedFont.name,
      zIndex: elements.length + 1,
    };
    
    setElements([...elements, newElement]);
    setSelectedElement(newElement);
  };

  const addSymbolElement = (symbol) => {
    const newElement = {
      id: `symbol-${Date.now()}`,
      type: 'symbol',
      image: symbol.image,
      x: 50,
      y: 150,
      width: 100,
      height: 100,
      zIndex: elements.length + 1,
    };
    
    setElements([...elements, newElement]);
    setSelectedElement(newElement);
  };

  const updateTextElement = (newText) => {
    if (selectedElement && selectedElement.type === 'text') {
      setElements(prevElements => 
        prevElements.map(el => 
          el.id === selectedElement.id ? { ...el, content: newText } : el
        )
      );
    }
  };

  const updateTextStyle = (property, value) => {
    if (selectedElement && selectedElement.type === 'text') {
      setElements(prevElements => 
        prevElements.map(el => 
          el.id === selectedElement.id ? { ...el, [property]: value } : el
        )
      );
    }
  };

  const deleteSelectedElement = () => {
    if (selectedElement && selectedElement.type !== 'background') {
      setElements(prevElements => 
        prevElements.filter(el => el.id !== selectedElement.id)
      );
      setSelectedElement(null);
    }
  };

  const renderCanvasElements = () => {
    return elements
      .sort((a, b) => a.zIndex - b.zIndex)
      .map(element => {
        if (element.type === 'background') {
          return (
            <Image
              key={element.id}
              source={{ uri: element.image }}
              style={[
                styles.backgroundImage,
                {
                  width: element.width,
                  height: element.height,
                }
              ]}
            />
          );
        } else if (element.type === 'text') {
          return (
            <Animated.View
              key={element.id}
              style={[
                styles.canvasElement,
                {
                  transform: [
                    { translateX: animatedValues[element.id]?.x || new Animated.Value(element.x) },
                    { translateY: animatedValues[element.id]?.y || new Animated.Value(element.y) },
                  ],
                  borderWidth: selectedElement?.id === element.id ? 1 : 0,
                }
              ]}
              {...(panResponders[element.id]?.panHandlers || {})}
            >
              <Text
                style={{
                  fontSize: element.fontSize,
                  color: element.color,
                  fontFamily: element.fontFamily,
                }}
                onLongPress={() => {
                  setSelectedElement(element);
                  setTextInputValue(element.content);
                  setTextInputVisible(true);
                }}
              >
                {element.content}
              </Text>
            </Animated.View>
          );
        } else if (element.type === 'symbol') {
          return (
            <Animated.View
              key={element.id}
              style={[
                styles.canvasElement,
                {
                  transform: [
                    { translateX: animatedValues[element.id]?.x || new Animated.Value(element.x) },
                    { translateY: animatedValues[element.id]?.y || new Animated.Value(element.y) },
                  ],
                  width: element.width,
                  height: element.height,
                  borderWidth: selectedElement?.id === element.id ? 1 : 0,
                }
              ]}
              {...(panResponders[element.id]?.panHandlers || {})}
            >
              <Image
                source={{ uri: element.image }}
                style={{ width: '100%', height: '100%', resizeMode: 'contain' }}
              />
            </Animated.View>
          );
        }
        return null;
      });
  };

  const renderTextTab = () => (
    <View style={styles.tabContent}>
      <View style={styles.textControls}>
        <TouchableOpacity style={styles.addButton} onPress={addTextElement}>
          <Text style={styles.addButtonText}>{i18n.t('addText')}</Text>
        </TouchableOpacity>
        
        {selectedElement && selectedElement.type === 'text' && (
          <>
            <TouchableOpacity 
              style={styles.editButton} 
              onPress={() => {
                setTextInputValue(selectedElement.content);
                setTextInputVisible(true);
              }}
            >
              <Text style={styles.editButtonText}>{i18n.t('edit')}</Text>
            </TouchableOpacity>
            
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.fontSelector}>
              {FONTS.map(font => (
                <TouchableOpacity
                  key={font.id}
                  style={[
                    styles.fontItem,
                    selectedFont.id === font.id && styles.selectedFontItem
                  ]}
                  onPress={() => {
                    setSelectedFont(font);
                    updateTextStyle('fontFamily', font.name);
                  }}
                >
                  <Text style={styles.fontItemText}>{font.name}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.colorSelector}>
              {COLORS.map(color => (
                <TouchableOpacity
                  key={color.id}
                  style={[
                    styles.colorItem,
                    { backgroundColor: color.value },
                    selectedColor.id === color.id && styles.selectedColorItem
                  ]}
                  onPress={() => {
                    setSelectedColor(color);
                    updateTextStyle('color', color.value);
                  }}
                />
              ))}
            </ScrollView>
          </>
        )}
      </View>
    </View>
  );

  const renderSymbolsTab = () => (
    <View style={styles.tabContent}>
      <ScrollView contentContainerStyle={styles.symbolsGrid}>
        {SYMBOLS.map(symbol => (
          <TouchableOpacity
            key={symbol.id}
            style={styles.symbolItem}
            onPress={() => addSymbolElement(symbol)}
          >
            <Image source={{ uri: symbol.image }} style={styles.symbolImage} />
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{i18n.t('edit')}</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerButton} onPress={() => navigation.goBack()}>
            <Text style={styles.headerButtonText}>{i18n.t('cancel')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.headerButton, styles.saveButton]}>
            <Text style={styles.headerButtonText}>{i18n.t('save')}</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.canvasContainer}>
        <View style={styles.canvas}>
          {renderCanvasElements()}
        </View>
      </View>

      {selectedElement && selectedElement.type !== 'background' && (
        <TouchableOpacity style={styles.deleteButton} onPress={deleteSelectedElement}>
          <Text style={styles.deleteButtonText}>حذف</Text>
        </TouchableOpacity>
      )}

      <View style={styles.tabsContainer}>
        <View style={styles.tabsHeader}>
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'text' && styles.activeTabButton]}
            onPress={() => setActiveTab('text')}
          >
            <Text style={styles.tabButtonText}>{i18n.t('addText')}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'symbols' && styles.activeTabButton]}
            onPress={() => setActiveTab('symbols')}
          >
            <Text style={styles.tabButtonText}>{i18n.t('addSymbol')}</Text>
          </TouchableOpacity>
        </View>

        {activeTab === 'text' && renderTextTab()}
        {activeTab === 'symbols' && renderSymbolsTab()}
      </View>

      {textInputVisible && (
        <View style={styles.textInputOverlay}>
          <View style={styles.textInputContainer}>
            <TextInput
              style={styles.textInput}
              value={textInputValue}
              onChangeText={setTextInputValue}
              multiline
              textAlign="right"
            />
            <View style={styles.textInputActions}>
              <TouchableOpacity
                style={styles.textInputButton}
                onPress={() => setTextInputVisible(false)}
              >
                <Text style={styles.textInputButtonText}>{i18n.t('cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.textInputButton, styles.confirmButton]}
                onPress={() => {
                  updateTextElement(textInputValue);
                  setTextInputVisible(false);
                }}
              >
                <Text style={styles.textInputButtonText}>{i18n.t('confirm')}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8FA',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#D4AF37',
  },
  headerActions: {
    flexDirection: 'row',
  },
  headerButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginLeft: 10,
  },
  saveButton: {
    backgroundColor: '#FFD1DC',
  },
  headerButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  canvasContainer: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  canvas: {
    width: SCREEN_WIDTH - 40,
    height: 400,
    backgroundColor: '#fff',
    borderRadius: 10,
    overflow: 'hidden',
    position: 'relative',
  },
  backgroundImage: {
    position: 'absolute',
    top: 0,
    left: 0,
    resizeMode: 'cover',
  },
  canvasElement: {
    position: 'absolute',
    padding: 5,
    borderColor: '#FFD1DC',
    borderStyle: 'dashed',
  },
  deleteButton: {
    position: 'absolute',
    right: 20,
    bottom: 200,
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#ff6b6b',
  },
  deleteButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
  },
  tabsContainer: {
    height: 200,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  tabsHeader: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTabButton: {
    borderBottomWidth: 2,
    borderBottomColor: '#FFD1DC',
  },
  tabButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  tabContent: {
    flex: 1,
    padding: 10,
  },
  textControls: {
    flex: 1,
  },
  addButton: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 20,
    ba
(Content truncated due to size limit. Use line ranges to read in chunks)