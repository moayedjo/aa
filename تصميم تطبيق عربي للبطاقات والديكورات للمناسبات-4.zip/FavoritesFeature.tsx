import React, { useState } from 'react';
import './FavoritesFeature.css';

// مكون حفظ القوالب المفضلة
const FavoritesFeature = () => {
  const [favorites, setFavorites] = useState([
    {
      id: 1,
      title: 'بطاقة عيد ميلاد',
      thumbnail: 'https://via.placeholder.com/100x150/FFD1DC/333333?text=عيد+ميلاد',
      category: 'بطاقات التهنئة',
      date: '15/05/2025'
    },
    {
      id: 2,
      title: 'ستوري رمضان',
      thumbnail: 'https://via.placeholder.com/100x150/BFEAF5/333333?text=رمضان',
      category: 'تصاميم الستوري',
      date: '10/05/2025'
    },
    {
      id: 3,
      title: 'بطاقة زفاف كلاسيكية',
      thumbnail: 'https://via.placeholder.com/100x150/D0F0C0/333333?text=زفاف',
      category: 'بطاقات الأفراح',
      date: '05/05/2025'
    }
  ]);

  const [activeFolder, setActiveFolder] = useState('الكل');
  const folders = ['الكل', 'بطاقات التهنئة', 'تصاميم الستوري', 'بطاقات الأفراح'];

  // تغيير المجلد النشط
  const changeFolder = (folder) => {
    setActiveFolder(folder);
  };

  // حذف تصميم من المفضلة
  const removeFromFavorites = (id) => {
    setFavorites(favorites.filter(fav => fav.id !== id));
  };

  // تحرير تصميم
  const editDesign = (id) => {
    alert(`فتح محرر التصميم للعنصر رقم ${id}`);
    // في التطبيق الحقيقي، سيتم توجيه المستخدم إلى محرر التصميم
  };

  // تصفية المفضلة حسب المجلد
  const filteredFavorites = activeFolder === 'الكل' 
    ? favorites 
    : favorites.filter(fav => fav.category === activeFolder);

  return (
    <div className="favorites-feature">
      <h2>التصاميم المفضلة</h2>
      
      <div className="folders-tabs">
        {folders.map(folder => (
          <button
            key={folder}
            className={`folder-tab ${activeFolder === folder ? 'active' : ''}`}
            onClick={() => changeFolder(folder)}
          >
            {folder}
          </button>
        ))}
      </div>
      
      <div className="favorites-list">
        {filteredFavorites.length > 0 ? (
          filteredFavorites.map(favorite => (
            <div key={favorite.id} className="favorite-item">
              <div className="favorite-thumbnail">
                <img src={favorite.thumbnail} alt={favorite.title} />
              </div>
              <div className="favorite-details">
                <h3>{favorite.title}</h3>
                <p className="favorite-category">{favorite.category}</p>
                <p className="favorite-date">تاريخ الحفظ: {favorite.date}</p>
                <div className="favorite-actions">
                  <button className="edit-button" onClick={() => editDesign(favorite.id)}>
                    تحرير
                  </button>
                  <button className="remove-button" onClick={() => removeFromFavorites(favorite.id)}>
                    إزالة
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="no-favorites">
            <p>لا توجد تصاميم مفضلة في هذا المجلد</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default FavoritesFeature;
