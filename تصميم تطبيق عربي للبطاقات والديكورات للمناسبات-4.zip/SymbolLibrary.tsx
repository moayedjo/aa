import React, { useState } from 'react';
import './SymbolLibrary.css';

// مكتبة الرموز والزخارف العربية والإسلامية
const SymbolLibrary = ({ onSelectSymbol }) => {
  const [activeCategory, setActiveCategory] = useState('islamic');
  
  // فئات الرموز والزخارف
  const categories = [
    { id: 'islamic', name: 'زخارف إسلامية' },
    { id: 'arabic', name: 'خطوط عربية' },
    { id: 'flowers', name: 'زهور وأوراق' },
    { id: 'borders', name: 'إطارات' },
    { id: 'occasions', name: 'مناسبات' }
  ];
  
  // الرموز والزخارف حسب الفئة
  const symbols = {
    islamic: [
      { id: 'i1', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=☪' },
      { id: 'i2', src: 'https://via.placeholder.com/50/BFEAF5/000000?text=⋆' },
      { id: 'i3', src: 'https://via.placeholder.com/50/D0F0C0/000000?text=۩' },
      { id: 'i4', src: 'https://via.placeholder.com/50/E6E6FA/000000?text=✧' },
      { id: 'i5', src: 'https://via.placeholder.com/50/FFFACD/000000?text=✿' },
      { id: 'i6', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=❁' }
    ],
    arabic: [
      { id: 'a1', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=بسم' },
      { id: 'a2', src: 'https://via.placeholder.com/50/BFEAF5/000000?text=الله' },
      { id: 'a3', src: 'https://via.placeholder.com/50/D0F0C0/000000?text=محمد' },
      { id: 'a4', src: 'https://via.placeholder.com/50/E6E6FA/000000?text=مبارك' },
      { id: 'a5', src: 'https://via.placeholder.com/50/FFFACD/000000?text=سعيد' },
      { id: 'a6', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=كريم' }
    ],
    flowers: [
      { id: 'f1', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=🌸' },
      { id: 'f2', src: 'https://via.placeholder.com/50/BFEAF5/000000?text=🌹' },
      { id: 'f3', src: 'https://via.placeholder.com/50/D0F0C0/000000?text=🌺' },
      { id: 'f4', src: 'https://via.placeholder.com/50/E6E6FA/000000?text=🌷' },
      { id: 'f5', src: 'https://via.placeholder.com/50/FFFACD/000000?text=🌻' },
      { id: 'f6', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=🍃' }
    ],
    borders: [
      { id: 'b1', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=◈◈◈' },
      { id: 'b2', src: 'https://via.placeholder.com/50/BFEAF5/000000?text=❋❋❋' },
      { id: 'b3', src: 'https://via.placeholder.com/50/D0F0C0/000000?text=✤✤✤' },
      { id: 'b4', src: 'https://via.placeholder.com/50/E6E6FA/000000?text=✽✽✽' },
      { id: 'b5', src: 'https://via.placeholder.com/50/FFFACD/000000?text=❃❃❃' },
      { id: 'b6', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=❀❀❀' }
    ],
    occasions: [
      { id: 'o1', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=🎂' },
      { id: 'o2', src: 'https://via.placeholder.com/50/BFEAF5/000000?text=🎓' },
      { id: 'o3', src: 'https://via.placeholder.com/50/D0F0C0/000000?text=💍' },
      { id: 'o4', src: 'https://via.placeholder.com/50/E6E6FA/000000?text=👶' },
      { id: 'o5', src: 'https://via.placeholder.com/50/FFFACD/000000?text=🎉' },
      { id: 'o6', src: 'https://via.placeholder.com/50/FFD1DC/000000?text=🎁' }
    ]
  };
  
  // تغيير الفئة النشطة
  const handleCategoryChange = (categoryId) => {
    setActiveCategory(categoryId);
  };
  
  // اختيار رمز
  const handleSymbolSelect = (symbol) => {
    if (onSelectSymbol) {
      onSelectSymbol(symbol.src);
    }
  };
  
  return (
    <div className="symbol-library">
      <h3>مكتبة الرموز والزخارف</h3>
      
      <div className="symbol-categories">
        {categories.map(category => (
          <button
            key={category.id}
            className={`category-button ${activeCategory === category.id ? 'active' : ''}`}
            onClick={() => handleCategoryChange(category.id)}
          >
            {category.name}
          </button>
        ))}
      </div>
      
      <div className="symbols-grid">
        {symbols[activeCategory].map(symbol => (
          <div
            key={symbol.id}
            className="symbol-item"
            onClick={() => handleSymbolSelect(symbol)}
          >
            <img src={symbol.src} alt="رمز" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default SymbolLibrary;
